/* hc ui bridge: seeds the Claude Design app's localStorage from goals.json
   before boot, applies local behavior patches without forking the checked-in
   artifact, mirrors edits through /api/import, and adds prompt assignment. */
(function () {
  "use strict";

  var KEY = "hc-vault-ui-v1";
  var SYNC_KEY = "hc-vault-ui-sync-v1";
  var promptState = { goals: [], prompts: [] };
  var promptStateFingerprint = null;
  var stateRevision = 0;
  var refreshPending = false;
  var panel = null;
  var panelSignature = null;
  var picker = null;
  var pickerTrigger = null;
  var pickerQuery = "";
  var pickerLimit = 80;
  var promptError = "";
  var pendingLinks = Object.create(null);
  var syncBusy = false;
  var lastObservedGoals = null;
  var analyzerState = null;
  var analyzerSignature = null;

  function replaceBundlePart(source, before, after) {
    if (source.indexOf(after) >= 0) return source;
    var at = source.indexOf(before);
    if (at < 0 || source.indexOf(before, at + before.length) >= 0) {
      throw new Error("goal UI bundle shape changed");
    }
    return source.slice(0, at) + after + source.slice(at + before.length);
  }

  // The design artifact is checked in byte-for-byte. Patch its component
  // source before the artifact runtime unpacks it rather than forking the
  // generated bundle or replacing the chat/prompt bridge around it.
  function patchBundleSource(source) {
    var parts = [
      [
        '<div sc-camel-on-click="{{ row.sel }}" sc-camel-on-double-click="{{ row.edit }}" style="display:flex;align-items:center;gap:7px;height:29px;padding:0 8px;border-radius:2px;cursor:pointer;background:{{ row.bg }}" style-hover="background:{{ row.hovBg }}">',
        '<div sc-camel-on-click="{{ row.sel }}" sc-camel-on-double-click="{{ row.edit }}" style="display:flex;align-items:center;gap:7px;min-height:29px;padding:0 8px;box-sizing:border-box;border-radius:2px;cursor:pointer;background:{{ row.bg }}" style-hover="background:{{ row.hovBg }}">'
      ],
      [
        '<sc-if value="{{ row.isEdit }}" hint-placeholder-val="{{ false }}"><input sc-camel-default-value="{{ row.rawTitle }}" sc-camel-on-key-down="{{ row.key }}" sc-camel-on-blur="{{ row.blur }}" ref="{{ row.ref }}" placeholder="Goal title" style="flex:1;min-width:80px;',
        '<sc-if value="{{ row.isEdit }}" hint-placeholder-val="{{ false }}"><input sc-camel-default-value="{{ row.rawTitle }}" sc-camel-on-key-down="{{ row.key }}" sc-camel-on-blur="{{ row.blur }}" ref="{{ row.ref }}" placeholder="Goal title" style="flex:1;min-width:0;'
      ],
      [
        '<sc-if value="{{ row.showTitle }}" hint-placeholder-val="{{ true }}"><span style="font-size:12.5px;color:{{ row.tcol }};font-weight:{{ row.fw }};text-decoration:{{ row.deco }}">{{ row.title }}</span></sc-if>',
        '<sc-if value="{{ row.showTitle }}" hint-placeholder-val="{{ true }}"><span style="flex:1 1 auto;min-width:0;padding:5px 0;font-size:12.5px;line-height:1.45;overflow-wrap:anywhere;color:{{ row.tcol }};font-weight:{{ row.fw }};text-decoration:{{ row.deco }}">{{ row.title }}</span></sc-if>'
      ],
      [
        '<span style="margin-left:auto;display:inline-flex;gap:10px;align-items:center">',
        '<span style="margin-left:auto;display:inline-flex;gap:10px;align-items:center;align-self:center;flex:none">'
      ],
      [
        '<span sc-camel-on-click="{{ row.addSub }}" title="Add subgoal" style="width:18px;height:18px;flex:none;display:flex;align-items:center;justify-content:center;font:500 12px \'Source Code Pro\',monospace;color:var(--fnt);cursor:pointer" style-hover="color:var(--acc);background:var(--hov)">+</span>',
        '<span sc-camel-on-click="{{ row.addSub }}" title="Add subgoal" style="height:18px;flex:none;display:flex;align-items:center;justify-content:center;padding:0 4px;font:500 10.5px \'Source Code Pro\',monospace;color:var(--fnt);cursor:pointer" style-hover="color:var(--acc);background:var(--hov)">+ Add subgoal</span>'
      ],
      [
        '<div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font:600 10px \'Source Code Pro\',monospace;letter-spacing:1.2px;color:var(--mut)">SELECTED GOAL</span><span sc-camel-on-click="{{ inspExpand }}"',
        '<div style="display:flex;justify-content:flex-end;align-items:baseline"><span sc-camel-on-click="{{ inspExpand }}"'
      ],
      [
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;gap:12px"><span style="font-size:11px;color:var(--fnt);min-width:0">Copy appends goal metadata</span><span style="flex:none;display:inline-flex;gap:18px;align-items:baseline">',
        '<div style="display:flex;align-items:center;justify-content:flex-end;margin-top:10px;gap:12px"><span style="flex:none;display:inline-flex;gap:18px;align-items:baseline">'
      ],
      [
        ' placeholder="Plan in markdown — # heading, - list, - [ ] task, **bold**, `code`" style="position:absolute;',
        ' aria-label="Goal notes" style="position:absolute;'
      ],
      [
        '<div style="margin-top:8px;font-size:11px;color:var(--fnt)">Markdown formats as you type · auto-saved with this goal</div>',
        '<!-- Notes save through component state. -->'
      ],
      [
        "      filter: (saved && saved.v >= 6 && saved.filter) ? saved.filter : 'active',\n      labels:",
        "      filter: (saved && saved.v >= 6 && saved.filter) ? saved.filter : 'active',\n      activeRetained: (saved && saved.v >= 7 && Array.isArray(saved.activeRetained)) ? saved.activeRetained : [],\n      labels:"
      ],
      [
        "  save() { try { const { goals, selId, filter, updatedAt, labels, paneTab, themeMode, view } = this.state; localStorage.setItem('hc-vault-ui-v1', JSON.stringify({ v: 6, goals, selId, filter, updatedAt, labels, paneTab, themeMode, view })); } catch (e) {} }",
        "  save() { try { const { goals, selId, filter, activeRetained, updatedAt, labels, paneTab, themeMode, view } = this.state; localStorage.setItem('hc-vault-ui-v1', JSON.stringify({ v: 7, goals, selId, filter, activeRetained, updatedAt, labels, paneTab, themeMode, view })); } catch (e) {} }"
      ],
      [
        "    const { goals, selId, filter, updatedAt, editId, copied, genN, genText, genFor, labels, paneTab } = this.state;",
        "    const { goals, selId, filter, activeRetained, updatedAt, editId, copied, genN, genText, genFor, labels, paneTab } = this.state;"
      ],
      [
        "    const keep = (n) => filter === 'all' ? true : filter === 'active' ? !n.done : filter === 'inprog' ? (!n.done && hasIp(n)) : hasDone(n);",
        "    const retained = new Set(activeRetained || []);\n    const keep = (n) => filter === 'all' ? true : filter === 'active' ? (!n.done || retained.has(n.id)) : filter === 'inprog' ? (!n.done && hasIp(n)) : hasDone(n);"
      ],
      [
        "        done: (e) => { e.stopPropagation(); this.set(s => ({ goals: this.up(s.goals, n.id, x => ({ ...x, done: !x.done })), editId: null }), true); },",
        "        done: (e) => { e.stopPropagation(); this.set(s => { const done = !n.done, kept = new Set(s.activeRetained || []); if (s.filter === 'active' && done) kept.add(n.id); else kept.delete(n.id); return { goals: this.up(s.goals, n.id, x => ({ ...x, done })), activeRetained: Array.from(kept), editId: null }; }, true); },"
      ],
      [
        "      click: () => this.set(() => ({ filter: k }))",
        "      click: () => this.set(s => ({ filter: k, activeRetained: s.filter === 'active' && k !== 'active' ? [] : s.activeRetained }))"
      ],
      [
        "        if (el) { const top = nx * 29, bot = top + 29; if (top < el.scrollTop) el.scrollTop = top; else if (bot > el.scrollTop + el.clientHeight) el.scrollTop = bot - el.clientHeight; }",
        "        if (el) { const marks = el.querySelectorAll('[title=\"Toggle complete\"]'), row = marks[nx] && marks[nx].parentElement; if (row) { const top = row.offsetTop, bot = top + row.offsetHeight; if (top < el.scrollTop) el.scrollTop = top; else if (bot > el.scrollTop + el.clientHeight) el.scrollTop = bot - el.clientHeight; } }"
      ],
      [
        "    const setSt = (k) => sel && this.set(s => ({ goals: this.up(s.goals, sel.id, x => k === 'done' ? { ...x, done: true } : { ...x, done: false, status: k === 'inprog' ? 'inprog' : 'todo' }) }), true);",
        "    const setSt = (k) => sel && this.set(s => { const kept = new Set(s.activeRetained || []); if (s.filter === 'active' && k === 'done') kept.add(sel.id); else kept.delete(sel.id); return { goals: this.up(s.goals, sel.id, x => k === 'done' ? { ...x, done: true } : { ...x, done: false, status: k === 'inprog' ? 'inprog' : 'todo' }), activeRetained: Array.from(kept) }; }, true);"
      ]
    ];
    return parts.reduce(function (patched, part) {
      return replaceBundlePart(patched, part[0], part[1]);
    }, source);
  }

  function patchBundleTemplate() {
    var template = document.querySelector('script[type="__bundler/template"]');
    if (!template) return false;
    try {
      template.textContent = JSON.stringify(patchBundleSource(
        JSON.parse(template.textContent)
      ));
      return true;
    } catch (error) {
      console.error("[hc ui] could not patch goal controls:", error);
      return false;
    }
  }

  function array(value) {
    return Array.isArray(value) ? value : [];
  }

  function toNode(g, byParent, todosOf) {
    var kids = (byParent[g.id] || []).map(function (c) {
      return toNode(c, byParent, todosOf);
    });
    var tds = (todosOf[g.id] || []).map(function (t, i) {
      return {
        id: "t:" + g.id + ":" + i,
        title: t.text,
        prio: "normal",
        done: !!t.done,
        open: true,
        status: "todo",
        notes: "",
        desc: "",
        labels: [],
        children: []
      };
    });
    return {
      id: g.id,
      title: g.title,
      prio: g.priority || "normal",
      done: g.status === "completed" || g.status === "abandoned",
      open: true,
      status: g.status === "in_progress" ? "inprog" : "todo",
      notes: g.notes || "",
      desc: g.description || "",
      labels: [],
      children: tds.concat(kids)
    };
  }

  function rootsFromState(st) {
    var byParent = {}, todosOf = {};
    array(st && st.goals).forEach(function (g) {
      todosOf[g.id] = g.todos || [];
      var parent = g.parent_goal_id || null;
      (byParent[parent] = byParent[parent] || []).push(g);
    });
    return (byParent[null] || []).map(function (g) {
      return toNode(g, byParent, todosOf);
    });
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function same(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
  }

  function readSync() {
    try {
      var value = JSON.parse(localStorage.getItem(SYNC_KEY) || "null");
      return value && typeof value.revision === "string" &&
        Array.isArray(value.goals) ? value : null;
    } catch (e) {
      return null;
    }
  }

  function writeSync(revision, goals) {
    try {
      localStorage.setItem(SYNC_KEY, JSON.stringify({
        revision: revision,
        goals: clone(goals)
      }));
    } catch (e) {}
  }

  function seedPayload(st, roots, saved) {
    saved = saved && typeof saved === "object" ? saved : {};
    var flat = flattenTree(roots).map;
    var filters = { active: true, inprog: true, done: true, all: true };
    var filter = filters[saved.filter] ? saved.filter : "active";
    var retained = filter === "active" ? array(saved.activeRetained).filter(function (id) {
      return typeof id === "string" && flat[id] && flat[id].value.done;
    }) : [];
    var selection = typeof saved.selId === "string" && flat[saved.selId] ?
      saved.selId : (roots.length ? roots[0].id : null);
    return {
      v: 7,
      goals: roots,
      selId: selection,
      filter: filter,
      activeRetained: retained,
      updatedAt: st.generated_at ? Date.parse(st.generated_at) : Date.now(),
      labels: array(saved.labels),
      paneTab: saved.paneTab === "notes" ? "notes" : "prompt",
      themeMode: saved.themeMode === "light" || saved.themeMode === "dark" ?
        saved.themeMode : null,
      view: saved.view === "tree" || saved.view === "inspect" ? saved.view : "split"
    };
  }

  function readLocalGoals() {
    try {
      var value = JSON.parse(localStorage.getItem(KEY) || "{}");
      return Array.isArray(value.goals) ? value.goals : [];
    } catch (e) {
      return [];
    }
  }

  function flattenTree(nodes) {
    var map = Object.create(null), order = [];
    function walk(list, parentId) {
      array(list).forEach(function (node) {
        if (!node || typeof node.id !== "string" || map[node.id]) return;
        var value = clone(node);
        delete value.children;
        map[node.id] = { value: value, parent: parentId };
        order.push(node.id);
        walk(node.children, node.id);
      });
    }
    walk(nodes, null);
    return { map: map, order: order };
  }

  // Three-way merge against the exact server tree the browser last synced.
  // Remote changes win for untouched fields; explicit local field edits,
  // additions, moves, and deletions survive. Remote additions are never
  // interpreted as local deletions merely because this browser never saw them.
  function mergeTrees(baseRoots, localRoots, remoteRoots) {
    var base = flattenTree(baseRoots), local = flattenTree(localRoots);
    var remote = flattenTree(remoteRoots), selected = Object.create(null);
    var order = remote.order.slice();
    local.order.forEach(function (id) {
      if (!remote.map[id] && !base.map[id]) order.push(id);
    });

    order.forEach(function (id) {
      var b = base.map[id], l = local.map[id], r = remote.map[id];
      if (r && b && !l) return; // an explicit local deletion
      if (!r && (!l || b)) return; // remote deletion, unless locally created
      if (!r && l && !b) {
        selected[id] = { value: clone(l.value), parent: l.parent };
        return;
      }
      if (r && !l) {
        selected[id] = { value: clone(r.value), parent: r.parent };
        return;
      }
      var value = clone(r.value);
      var keys = Object.keys(l.value);
      keys.forEach(function (key) {
        if (key === "id") return;
        if (!b || !same(l.value[key], b.value[key])) {
          value[key] = clone(l.value[key]);
        }
      });
      var parent = r.parent;
      if (!b || l.parent !== b.parent) parent = l.parent;
      selected[id] = { value: value, parent: parent };
    });

    var children = Object.create(null), roots = [];
    order.forEach(function (id) {
      var row = selected[id];
      if (!row) return;
      row.value.children = [];
      var parent = row.parent;
      if (!parent || !selected[parent] || parent === id) {
        roots.push(row.value);
      } else {
        (children[parent] = children[parent] || []).push(row.value);
      }
    });
    order.forEach(function (id) {
      if (selected[id]) selected[id].value.children = children[id] || [];
    });
    return roots;
  }

  function acceptState(st) {
    if (!st || !Array.isArray(st.goals)) return false;
    var nextAnalyzer = st.analyzer && typeof st.analyzer === "object" ?
      st.analyzer : null;
    if (!same(nextAnalyzer, analyzerState)) {
      analyzerState = nextAnalyzer;
      analyzerSignature = null;
    }
    var next = {
      goals: st.goals,
      // The endpoint is intentionally human-only. Keep the role check here so
      // an accidental future expansion cannot expose assistant/tool turns.
      prompts: array(st.prompts).filter(function (p) {
        return p && p.role === "user" && typeof p.id === "string" &&
          typeof p.text === "string";
      })
    };
    var fingerprint = JSON.stringify([
      next.goals.map(function (g) { return [g.id, attachedIds(g)]; }),
      next.prompts
    ]);
    if (fingerprint === promptStateFingerprint) return true;
    promptStateFingerprint = fingerprint;
    promptState = next;
    stateRevision += 1;
    panelSignature = null;
    renderPanel();
    renderPickerList(true);
    return true;
  }

  function seed() {
    try {
      var x = new XMLHttpRequest();
      x.open("GET", "/api/state", false);   // sync on purpose: must beat app boot
      x.send();
      var st = JSON.parse(x.responseText);
      if (!acceptState(st)) return;
      var roots = rootsFromState(st);
      var saved = null;
      try { saved = JSON.parse(localStorage.getItem(KEY) || "null"); }
      catch (e) {}
      localStorage.setItem(KEY, JSON.stringify(seedPayload(st, roots, saved)));
      window.__hcSeed = JSON.stringify(roots);
      lastObservedGoals = window.__hcSeed;
      if (typeof st.revision === "string") writeSync(st.revision, roots);
    } catch (e) {
      // Offline model missing: let the app boot with whatever it already has.
    }
  }

  function watchGoals() {
    setInterval(function () {
      if (syncBusy) return;
      var raw;
      try { raw = localStorage.getItem(KEY); } catch (e) { return; }
      if (!raw) return;
      var goals;
      try { goals = JSON.stringify(JSON.parse(raw).goals); } catch (e) { return; }
      if (goals === lastObservedGoals) return;
      lastObservedGoals = goals;
      importGoals(JSON.parse(goals));
    }, 800);
  }

  function responseJson(response) {
    return response.json().then(function (body) {
      if (!response.ok || !body || body.ok !== true) {
        var error = new Error(body && body.error ? body.error :
          "request failed (" + response.status + ")");
        error.status = response.status;
        throw error;
      }
      return body;
    });
  }

  function postImport(goals, baseRevision) {
    return fetch("/api/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ goals: goals, base_revision: baseRevision })
    }).then(responseJson);
  }

  function importGoals(goals) {
    var synced = readSync();
    if (!synced) {
      lastObservedGoals = null;
      refreshState();
      return;
    }
    syncBusy = true;
    postImport(goals, synced.revision).then(function (result) {
      writeSync(result.revision, goals);
      syncBusy = false;
      refreshState();
    }).catch(function () {
      // A revision conflict is expected when analysis and a browser edit race.
      // Re-fetch and three-way merge; transient failures retry on the next tick.
      syncBusy = false;
      lastObservedGoals = null;
      refreshState();
    });
  }

  function installGoalsAndReload(goals, revision) {
    var saved;
    try { saved = JSON.parse(localStorage.getItem(KEY) || "{}"); }
    catch (e) { saved = {}; }
    saved.goals = goals;
    var ids = flattenTree(goals).map;
    if (typeof saved.selId !== "string" || !ids[saved.selId]) {
      saved.selId = goals.length ? goals[0].id : null;
    }
    saved.updatedAt = Date.now();
    localStorage.setItem(KEY, JSON.stringify(saved));
    writeSync(revision, goals);
    lastObservedGoals = JSON.stringify(goals);
    syncBusy = true;
    window.location.reload();
  }

  function reconcileState(st) {
    if (!st || typeof st.revision !== "string") return;
    var remote = rootsFromState(st);
    var synced = readSync();
    if (!synced) {
      writeSync(st.revision, remote);
      return;
    }
    if (synced.revision === st.revision) return;
    var local = readLocalGoals();
    var merged = mergeTrees(synced.goals, local, remote);
    if (same(merged, remote)) {
      writeSync(st.revision, remote);
      if (!same(local, remote)) installGoalsAndReload(remote, st.revision);
      return;
    }
    syncBusy = true;
    postImport(merged, st.revision).then(function (result) {
      installGoalsAndReload(merged, result.revision);
    }).catch(function () {
      syncBusy = false;
      lastObservedGoals = null;
      setTimeout(refreshState, 50);
    });
  }

  function refreshState() {
    if (refreshPending) return;
    refreshPending = true;
    fetch("/api/state", { cache: "no-store" })
      .then(function (r) {
        if (!r.ok) throw new Error("state request failed (" + r.status + ")");
        return r.json();
      })
      .then(function (st) {
        acceptState(st);
        reconcileState(st);
      })
      .catch(function () {})
      .then(function () { refreshPending = false; });
  }

  function readSelection() {
    try {
      var saved = JSON.parse(localStorage.getItem(KEY) || "{}");
      return typeof saved.selId === "string" ? saved.selId : null;
    } catch (e) {
      return null;
    }
  }

  function goalById(id) {
    return promptState.goals.find(function (g) { return g.id === id; }) || null;
  }

  function promptById(id) {
    return promptState.prompts.find(function (p) { return p.id === id; }) || null;
  }

  function attachedIds(goal) {
    return array(goal && goal.prompt_ids).filter(function (id) {
      return typeof id === "string";
    });
  }

  function normalize(text) {
    var out = String(text || "").toLowerCase();
    try { out = out.normalize("NFKD").replace(/[\u0300-\u036f]/g, ""); }
    catch (e) {}
    return out.replace(/[^a-z0-9]+/g, " ").trim();
  }

  function subsequenceScore(needle, haystack) {
    var at = 0, score = 0, run = 0;
    for (var i = 0; i < haystack.length && at < needle.length; i += 1) {
      if (haystack[i] === needle[at]) {
        run += 1;
        score += 4 + run * 2;
        at += 1;
      } else {
        run = 0;
        score -= 0.08;
      }
    }
    return at === needle.length ? score : null;
  }

  // Word-aware fuzzy matching: exact phrases lead, then exact/prefix/substring
  // word matches, then ordered character subsequences. Every query token must
  // match, preventing a strong first word from hiding a missing second word.
  function fuzzyScore(query, text) {
    var q = normalize(query), t = normalize(text);
    if (!q) return 0;
    if (!t) return null;
    var phraseAt = t.indexOf(q);
    var total = phraseAt >= 0 ? 2000 - phraseAt : 0;
    var words = t.split(" ");
    var tokens = q.split(" ");
    for (var i = 0; i < tokens.length; i += 1) {
      var token = tokens[i], best = null;
      for (var j = 0; j < words.length; j += 1) {
        var word = words[j], score = null;
        if (word === token) score = 500 - j;
        else if (word.indexOf(token) === 0) score = 400 - j - (word.length - token.length);
        else if (word.indexOf(token) >= 0) score = 300 - j - word.indexOf(token);
        else {
          var seq = subsequenceScore(token, word);
          if (seq !== null) score = 100 + seq - j;
        }
        if (score !== null && (best === null || score > best)) best = score;
      }
      if (best === null) return null;
      total += best;
    }
    return total;
  }

  function recency(prompt, index) {
    var ordinal = Number(prompt.ordinal);
    if (Number.isFinite(ordinal)) return ordinal;
    var stamp = Date.parse(prompt.created_at || "");
    return Number.isFinite(stamp) ? stamp : index;
  }

  function rankedPrompts(query) {
    return promptState.prompts.map(function (prompt, index) {
      return {
        prompt: prompt,
        score: fuzzyScore(query, prompt.text),
        recent: recency(prompt, index),
        index: index
      };
    }).filter(function (row) {
      return row.score !== null;
    }).sort(function (a, b) {
      return b.recent - a.recent || b.index - a.index;
    }).map(function (row) { return row.prompt; });
  }

  function findText(text) {
    var els = document.querySelectorAll("span");
    for (var i = 0; i < els.length; i += 1) {
      if (els[i].textContent.trim() === text) return els[i];
    }
    return null;
  }

  function ensureStyles() {
    if (document.getElementById("hc-prompt-style")) return;
    var style = document.createElement("style");
    style.id = "hc-prompt-style";
    style.textContent = [
      ".hc-pa{margin-top:13px;padding-top:12px;border-top:1px solid var(--bd)}",
      ".hc-pa-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px}",
      ".hc-pa-label{font:600 9.5px 'Source Code Pro',monospace;letter-spacing:1px;color:var(--fnt)}",
      ".hc-pa-add,.hc-pa-remove,.hc-pa-close{border:0;background:transparent;font-family:'Source Code Pro',monospace;color:var(--acc);cursor:pointer;padding:0}",
      ".hc-pa-add{font-size:11px}.hc-pa-add:hover,.hc-pa-remove:hover{text-decoration:underline}",
      ".hc-pa-list{display:flex;flex-direction:column;gap:6px;margin-top:8px}",
      ".hc-pa-card{display:flex;gap:8px;align-items:flex-start;border-left:2px solid var(--bd2);padding:5px 0 5px 8px;min-width:0}",
      ".hc-pa-text{flex:1;min-width:0;font:11px/1.45 'Source Code Pro',monospace;color:var(--mut);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;white-space:pre-wrap}",
      ".hc-pa-remove{flex:none;color:var(--fnt);font-size:13px;line-height:1.2}.hc-pa-remove:hover{color:var(--del)}",
      ".hc-pa-empty,.hc-pa-error{margin-top:7px;font:10.5px/1.45 'Source Code Pro',monospace;color:var(--fnt)}",
      ".hc-pa-error{color:var(--del)}",
      ".hc-pa-overlay{position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.28);display:flex;align-items:center;justify-content:center;padding:20px}",
      ".hc-pa-overlay[hidden]{display:none}",
      ".hc-pa-dialog{width:min(620px,100%);max-height:min(680px,calc(100vh - 40px));display:flex;flex-direction:column;background:var(--panel,#fff);color:var(--ink,#111);border:1px solid var(--bd2,#d5d5d5);border-radius:3px;box-shadow:0 18px 60px rgba(0,0,0,.2);font-family:'Source Code Pro',monospace}",
      ".hc-pa-dialog-head{display:flex;align-items:baseline;justify-content:space-between;padding:14px 16px 10px}",
      ".hc-pa-dialog-title{font-size:12.5px;font-weight:700}",
      ".hc-pa-close{font-size:16px;color:var(--fnt)}.hc-pa-close:hover{color:var(--ink)}",
      ".hc-pa-search{margin:0 16px 10px;width:calc(100% - 32px);box-sizing:border-box;border:1px solid var(--bd2);border-radius:2px;background:var(--panel2);color:var(--ink);outline:none;padding:8px 10px;font:11.5px 'Source Code Pro',monospace}",
      ".hc-pa-search:focus{border-color:var(--acc);box-shadow:0 0 0 2px var(--acchov)}",
      ".hc-pa-results{overflow-y:auto;overscroll-behavior:contain;border-top:1px solid var(--bd);border-bottom:1px solid var(--bd);max-height:52vh}",
      ".hc-pa-result{width:100%;display:flex;align-items:flex-start;gap:10px;text-align:left;border:0;border-bottom:1px solid var(--bd);background:transparent;color:var(--ink);padding:10px 16px;cursor:pointer;font-family:'Source Code Pro',monospace}",
      ".hc-pa-result:last-child{border-bottom:0}.hc-pa-result:hover{background:var(--acchov)}",
      ".hc-pa-check{width:13px;height:13px;flex:none;margin-top:2px;border:1.5px solid var(--fnt);border-radius:2px;color:var(--onacc);font:9px/11px 'Source Code Pro',monospace;text-align:center}",
      ".hc-pa-result[data-attached='true'] .hc-pa-check{background:var(--acc);border-color:var(--acc)}",
      ".hc-pa-result-body{display:block;min-width:0;flex:1}.hc-pa-result-meta{display:block;font-size:9.5px;color:var(--fnt);margin-bottom:4px}",
      ".hc-pa-result-text{display:block;font-size:11.5px;line-height:1.45;color:var(--mut);white-space:pre-wrap;word-break:break-word}",
      ".hc-pa-result[disabled]{cursor:wait;opacity:.6}",
      ".hc-pa-foot{padding:8px 16px;font-size:10px;color:var(--fnt)}",
      ".hc-analyzer-state{position:fixed;right:18px;bottom:16px;z-index:99990;padding:6px 9px;border:1px solid var(--bd,#ddd);border-radius:2px;background:var(--panel,#fff);color:var(--fnt,#777);box-shadow:0 3px 16px rgba(0,0,0,.08);font:10.5px/1.35 'Source Code Pro',monospace}",
      ".hc-analyzer-state[data-status='error']{color:var(--del,#a33);border-color:var(--del,#a33)}",
      "@media(max-width:700px){.hc-pa-overlay{padding:8px}.hc-pa-dialog{max-height:calc(100vh - 16px)}}"
    ].join("");
    document.head.appendChild(style);
  }

  function makeButton(className, label, title) {
    var button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = label;
    if (title) button.title = title;
    return button;
  }

  function ensurePanel() {
    var selected = readSelection();
    var goal = goalById(selected);
    var promptTab = findText("PROMPT");
    var tabs = promptTab && promptTab.parentElement;
    var inspector = tabs && tabs.parentElement;
    if (!goal || !tabs || !inspector || !inspector.contains(promptTab)) {
      if (panel) panel.style.display = "none";
      if (picker) closePicker();
      return null;
    }
    ensureStyles();
    // The bundle hydrates in phases and may clone an inspector after the
    // first bridge mount. Adopt one surviving panel and remove cloned copies.
    var existing = inspector.querySelectorAll("#hc-prompt-links");
    if (!panel || !document.documentElement.contains(panel) || !inspector.contains(panel)) {
      panel = existing.length ? existing[existing.length - 1] : null;
      panelSignature = null;
    }
    for (var i = 0; i < existing.length; i += 1) {
      if (existing[i] !== panel) existing[i].remove();
    }
    if (!panel || !document.documentElement.contains(panel)) {
      panel = document.createElement("section");
      panel.id = "hc-prompt-links";
      panel.className = "hc-pa";
      tabs.parentNode.insertBefore(panel, tabs);
      panelSignature = null;
    } else if (panel.parentNode !== tabs.parentNode || panel.nextSibling !== tabs) {
      tabs.parentNode.insertBefore(panel, tabs);
    }
    panel.style.display = "block";
    return goal;
  }

  function formatPromptMeta(prompt) {
    var parts = [];
    if (Number.isFinite(Number(prompt.ordinal))) parts.push("turn " + Number(prompt.ordinal));
    var date = new Date(prompt.created_at || "");
    if (!Number.isNaN(date.getTime())) {
      parts.push(date.toLocaleDateString("en-US", { month: "short", day: "numeric" }) +
        ", " + date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }));
    }
    return parts.join(" · ") || "human prompt";
  }

  function renderPanel() {
    var goal = ensurePanel();
    if (!goal || !panel) return;
    var ids = attachedIds(goal);
    var sig = goal.id + "|" + stateRevision + "|" + ids.join(",") + "|" +
      promptError + "|" + Object.keys(pendingLinks).join(",");
    if (sig === panelSignature) return;
    panelSignature = sig;
    panel.textContent = "";

    var head = document.createElement("div");
    head.className = "hc-pa-head";
    var label = document.createElement("span");
    label.className = "hc-pa-label";
    label.textContent = "CHAT PROMPTS" + (ids.length ? " (" + ids.length + ")" : "");
    var add = makeButton("hc-pa-add", "+ attach from chat");
    add.onclick = openPicker;
    head.appendChild(label);
    head.appendChild(add);
    panel.appendChild(head);

    var list = document.createElement("div");
    list.className = "hc-pa-list";
    ids.forEach(function (id) {
      var prompt = promptById(id);
      if (!prompt) return;
      var card = document.createElement("div");
      card.className = "hc-pa-card";
      card.title = formatPromptMeta(prompt);
      var text = document.createElement("span");
      text.className = "hc-pa-text";
      text.textContent = prompt.text;
      var remove = makeButton("hc-pa-remove", "×", "Detach this prompt");
      remove.disabled = !!pendingLinks[goal.id + "\u0000" + id];
      remove.onclick = function () { setPromptLink(goal.id, id, false); };
      card.appendChild(text);
      card.appendChild(remove);
      list.appendChild(card);
    });
    if (!list.childNodes.length) {
      var empty = document.createElement("div");
      empty.className = "hc-pa-empty";
      empty.textContent = promptState.prompts.length ?
        "No chat prompts attached to this goal." : "No human prompts have streamed into this chat yet.";
      list.appendChild(empty);
    }
    panel.appendChild(list);
    if (promptError) {
      var error = document.createElement("div");
      error.className = "hc-pa-error";
      error.setAttribute("role", "alert");
      error.textContent = promptError;
      panel.appendChild(error);
    }
  }

  function createPicker() {
    if (picker && document.documentElement.contains(picker)) return picker;
    picker = document.createElement("div");
    picker.id = "hc-prompt-picker";
    picker.className = "hc-pa-overlay";
    picker.hidden = true;
    picker.onclick = function (e) { if (e.target === picker) closePicker(); };

    var dialog = document.createElement("div");
    dialog.className = "hc-pa-dialog";
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-labelledby", "hc-pa-picker-title");
    var head = document.createElement("div");
    head.className = "hc-pa-dialog-head";
    var title = document.createElement("span");
    title.id = "hc-pa-picker-title";
    title.className = "hc-pa-dialog-title";
    title.textContent = "Attach chat prompts";
    var close = makeButton("hc-pa-close", "×", "Close prompt picker");
    close.onclick = closePicker;
    head.appendChild(title);
    head.appendChild(close);

    var search = document.createElement("input");
    search.type = "search";
    search.className = "hc-pa-search";
    search.placeholder = "Search human messages…";
    search.autocomplete = "off";
    search.setAttribute("aria-label", "Search human messages");
    search.oninput = function () {
      pickerQuery = search.value;
      pickerLimit = 80;
      renderPickerList();
    };
    var results = document.createElement("div");
    results.className = "hc-pa-results";
    results.setAttribute("role", "listbox");
    results.onscroll = function () {
      if (results.scrollTop + results.clientHeight >= results.scrollHeight - 80) {
        var total = rankedPrompts(pickerQuery).length;
        if (pickerLimit < total) {
          pickerLimit += 80;
          renderPickerList(true);
        }
      }
    };
    var foot = document.createElement("div");
    foot.className = "hc-pa-foot";
    dialog.appendChild(head);
    dialog.appendChild(search);
    dialog.appendChild(results);
    dialog.appendChild(foot);
    picker.appendChild(dialog);
    // Keep the modal inside the app root so its light/dark CSS variables are
    // inherited. Fixed positioning still makes it viewport-relative.
    (document.querySelector(".hc") || document.body).appendChild(picker);
    return picker;
  }

  function openPicker(event) {
    var goal = goalById(readSelection());
    if (!goal) return;
    var trigger = event && event.currentTarget;
    pickerTrigger = trigger && typeof trigger.focus === "function" ?
      trigger : document.activeElement;
    ensureStyles();
    createPicker();
    promptError = "";
    pickerQuery = "";
    pickerLimit = 80;
    picker.hidden = false;
    var search = picker.querySelector(".hc-pa-search");
    search.value = "";
    renderPickerList();
    setTimeout(function () { search.focus(); }, 0);
  }

  function closePicker() {
    if (picker) picker.hidden = true;
    var target = pickerTrigger;
    pickerTrigger = null;
    if (target && typeof target.focus === "function" &&
        document.documentElement.contains(target)) {
      setTimeout(function () { target.focus(); }, 0);
    }
  }

  function renderPickerList(keepScroll) {
    if (!picker || picker.hidden) return;
    var goal = goalById(readSelection());
    if (!goal) { closePicker(); return; }
    var results = picker.querySelector(".hc-pa-results");
    var foot = picker.querySelector(".hc-pa-foot");
    if (!results || !foot) return;
    var oldTop = keepScroll ? results.scrollTop : 0;
    var attached = new Set(attachedIds(goal));
    var ranked = rankedPrompts(pickerQuery);
    var shown = ranked.slice(0, pickerLimit);
    results.textContent = "";
    shown.forEach(function (prompt) {
      var linked = attached.has(prompt.id);
      var key = goal.id + "\u0000" + prompt.id;
      var row = makeButton("hc-pa-result", "");
      row.setAttribute("role", "option");
      row.setAttribute("aria-selected", linked ? "true" : "false");
      row.dataset.attached = linked ? "true" : "false";
      row.disabled = !!pendingLinks[key];
      var check = document.createElement("span");
      check.className = "hc-pa-check";
      check.textContent = linked ? "✓" : "";
      var body = document.createElement("span");
      body.className = "hc-pa-result-body";
      var meta = document.createElement("span");
      meta.className = "hc-pa-result-meta";
      meta.textContent = formatPromptMeta(prompt);
      var text = document.createElement("span");
      text.className = "hc-pa-result-text";
      text.textContent = prompt.text;
      body.appendChild(meta);
      body.appendChild(text);
      row.appendChild(check);
      row.appendChild(body);
      row.onclick = function () { setPromptLink(goal.id, prompt.id, !linked); };
      results.appendChild(row);
    });
    if (!shown.length) {
      var empty = document.createElement("div");
      empty.className = "hc-pa-empty";
      empty.style.padding = "18px 16px";
      empty.textContent = promptState.prompts.length ?
        "No human message matches that search." : "No human prompts have streamed into this chat yet.";
      results.appendChild(empty);
    }
    foot.textContent = shown.length < ranked.length ?
      "showing " + shown.length + " of " + ranked.length + " · scroll for older prompts" :
      ranked.length + (ranked.length === 1 ? " human prompt" : " human prompts") + " · newest first";
    if (keepScroll) results.scrollTop = oldTop;
  }

  function setPromptLink(goalId, promptId, attach) {
    var goal = goalById(goalId);
    if (!goal || !promptById(promptId)) return;
    var key = goalId + "\u0000" + promptId;
    if (pendingLinks[key]) return;
    var before = attachedIds(goal);
    var has = before.indexOf(promptId) >= 0;
    if (has === attach) return;
    pendingLinks[key] = true;
    promptError = "";
    goal.prompt_ids = attach ? before.concat([promptId]) : before.filter(function (id) {
      return id !== promptId;
    });
    stateRevision += 1;
    panelSignature = null;
    renderPanel();
    renderPickerList();

    fetch("/api/op", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        op: attach ? "attach_prompt" : "detach_prompt",
        goal_id: goalId,
        prompt_id: promptId
      })
    }).then(function (r) {
      if (!r.ok) throw new Error("request failed (" + r.status + ")");
      return r.json();
    }).then(function (result) {
      if (!result || result.ok !== true) {
        throw new Error(result && result.error ? result.error : "link was rejected");
      }
      delete pendingLinks[key];
      stateRevision += 1;
      panelSignature = null;
      renderPanel();
      renderPickerList();
      refreshState();
    }).catch(function (error) {
      goal.prompt_ids = before;
      delete pendingLinks[key];
      promptError = "Could not " + (attach ? "attach" : "detach") + " prompt: " + error.message;
      stateRevision += 1;
      panelSignature = null;
      renderPanel();
      renderPickerList();
    });
  }

  function renderAnalyzerStatus() {
    var status = analyzerState && analyzerState.status;
    var visible = promptState.goals.length === 0 &&
      (status === "pending" || status === "running" || status === "error");
    var signature = visible ? status : "hidden";
    if (signature === analyzerSignature) return;
    analyzerSignature = signature;
    var indicator = document.getElementById("hc-analyzer-state");
    if (!visible) {
      if (indicator) indicator.remove();
      return;
    }
    ensureStyles();
    if (!indicator) {
      indicator = document.createElement("div");
      indicator.id = "hc-analyzer-state";
      indicator.className = "hc-analyzer-state";
      indicator.setAttribute("aria-live", "polite");
      (document.querySelector(".hc") || document.body).appendChild(indicator);
    }
    indicator.dataset.status = status;
    indicator.setAttribute("role", status === "error" ? "alert" : "status");
    indicator.textContent = status === "error" ?
      "goal analysis failed" : "analyzing this chat\u2026";
  }

  function mountPromptUI() {
    renderAnalyzerStatus();
    renderPanel();
    if (picker && !picker.hidden && !document.documentElement.contains(picker)) {
      picker = null;
      closePicker();
    }
  }

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && picker && !picker.hidden) {
      e.preventDefault();
      closePicker();
    }
  }, true);

  // Test seam for the pure ordering/matching behavior; no backend state is
  // exposed, and production code does not depend on this object.
  window.__hcPromptUI = {
    fuzzyScore: fuzzyScore,
    normalize: normalize,
    rankedPrompts: rankedPrompts,
    acceptState: acceptState,
    selectedGoalId: readSelection,
    mergeTrees: mergeTrees,
    rootsFromState: rootsFromState,
    patchBundleSource: patchBundleSource,
    seedPayload: seedPayload
  };

  seed();
  // The server places this script after the template island and before the
  // closing body tag. Patch synchronously: the bundle's DOMContentLoaded
  // listener has been registered, but cannot unpack the template yet.
  patchBundleTemplate();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      watchGoals();
      setInterval(refreshState, 1500);
      setInterval(mountPromptUI, 250);
      setTimeout(refreshState, 0);
    });
  } else {
    watchGoals();
    setInterval(refreshState, 1500);
    setInterval(mountPromptUI, 250);
    setTimeout(refreshState, 0);
  }
})();
